import spotipy
from spotipy.oauth2 import SpotifyOAuth
import json
from pathlib import Path

def _get_spotify_client():
    config_path = Path(__file__).resolve().parent.parent / "config" / "api_keys.json"
    try:
        with open(config_path, "r") as f:
            config = json.load(f)
        
        sp = spotipy.Spotify(auth_manager=SpotifyOAuth(
            client_id=config.get("spotify_client_id"),
            client_secret=config.get("spotify_client_secret"),
            redirect_uri=config.get("spotify_redirect_uri", "http://localhost:8888/callback"),
            scope="user-modify-playback-state user-read-playback-state user-read-currently-playing"
        ))
        return sp
    except Exception as e:
        print(f"[Spotify] ⚠️ Auth failed: {e}")
        return None

def spotify_control(parameters: dict, **kwargs) -> str:
    """
    Controls Spotify playback: play, pause, next, previous, or search and play.
    Parameters:
        action (str): 'play', 'pause', 'next', 'previous', 'search'
        query (str): Song/Artist name for search
    """
    action = parameters.get("action", "play").lower()
    query = parameters.get("query", "")
    
    sp = _get_spotify_client()
    if not sp:
        return "Spotify authentication failed. Please check your credentials in config/api_keys.json."
    
    try:
        if action == "play":
            if query:
                results = sp.search(q=query, limit=1, type="track")
                if results['tracks']['items']:
                    track_uri = results['tracks']['items'][0]['uri']
                    sp.start_playback(uris=[track_uri])
                    return f"Playing {results['tracks']['items'][0]['name']} by {results['tracks']['items'][0]['artists'][0]['name']} on Spotify."
                return f"Could not find '{query}' on Spotify."
            else:
                sp.start_playback()
                return "Resumed Spotify playback."
                
        elif action == "pause":
            sp.pause_playback()
            return "Paused Spotify playback."
            
        elif action == "next":
            sp.next_track()
            return "Skipped to the next track on Spotify."
            
        elif action == "previous":
            sp.previous_track()
            return "Went back to the previous track on Spotify."
            
        elif action == "search":
            results = sp.search(q=query, limit=3, type="track")
            tracks = [f"{t['name']} by {t['artists'][0]['name']}" for t in results['tracks']['items']]
            return "Found tracks: " + ", ".join(tracks)
            
        return f"Unknown Spotify action: {action}"
    except Exception as e:
        if "device" in str(e).lower():
            return "No active Spotify device found. Please open Spotify on your phone or PC."
        return f"Spotify error: {e}"
