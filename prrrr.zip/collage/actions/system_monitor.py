import psutil
import platform
import time

def get_system_stats() -> str:
    """
    Retrieves real-time system health information: CPU, RAM, Disk, and Battery.
    """
    try:
        cpu_usage = psutil.cpu_percent(interval=0.5)
        ram = psutil.virtual_memory()
        disk = psutil.disk_usage('/')
        
        battery = psutil.sensors_battery()
        battery_info = ""
        if battery:
            plugged = "Plugged In" if battery.power_plugged else "Discharging"
            battery_info = f"\n- Battery: {battery.percent}% ({plugged})"
            
        os_info = f"{platform.system()} {platform.release()}"
        
        report = (
            f"System Health Report ({os_info}):\n"
            f"- CPU Usage: {cpu_usage}%\n"
            f"- RAM Usage: {ram.percent}% ({ram.used // (1024**2)}MB / {ram.total // (1024**2)}MB)\n"
            f"- Disk Usage: {disk.percent}% ({disk.free // (1024**3)}GB Free)"
            f"{battery_info}"
        )
        return report
    except Exception as e:
        return f"Error retrieving system stats: {e}"

def system_monitor(parameters: dict, **kwargs) -> str:
    """
    Tool interface for the SHUBHAM agent.
    """
                                                             
    return get_system_stats()
