import imaplib
import email
from email.header import decode_header
import json
from pathlib import Path

def _get_email_credentials():
    config_path = Path(__file__).resolve().parent.parent / "config" / "api_keys.json"
    try:
        with open(config_path, "r") as f:
            config = json.load(f)
        return config.get("email_user"), config.get("email_pass"), config.get("email_imap_server", "imap.gmail.com")
    except Exception:
        return None, None, None

def read_emails(limit=5) -> str:
    user, password, imap_server = _get_email_credentials()
    if not user or not password:
        return "Email credentials missing in config/api_keys.json. Need email_user and email_pass."
    
    try:
        mail = imaplib.IMAP4_SSL(imap_server)
        mail.login(user, password)
        mail.select("inbox")
        
        status, messages = mail.search(None, "ALL")
        email_ids = messages[0].split()
        
        results = []
        for i in range(1, min(limit + 1, len(email_ids) + 1)):
            status, msg_data = mail.fetch(email_ids[-i], "(RFC822)")
            for response_part in msg_data:
                if isinstance(response_part, tuple):
                    msg = email.message_from_bytes(response_part[1])
                    subject, encoding = decode_header(msg["Subject"])[0]
                    if isinstance(subject, bytes):
                        subject = subject.decode(encoding if encoding else "utf-8")
                    sender = msg.get("From")
                    results.append(f"Subject: {subject}\nFrom: {sender}")
                    
        mail.logout()
        if not results:
            return "No emails found in your inbox."
        return "Recent Emails:\n" + "\n---\n".join(results)
    except Exception as e:
        return f"Email error: {e}. If using Gmail, make sure App Passwords are enabled."

def email_helper(parameters: dict, **kwargs) -> str:
    """
    Reads or summarizes emails.
    Parameters:
        action (str): 'read', 'summarize'
        count (int): Number of emails to check
    """
    action = parameters.get("action", "read").lower()
    count = int(parameters.get("count", 5))
    
    if action in ("read", "summarize"):
        return read_emails(limit=count)
    return f"Unknown email action: {action}"
